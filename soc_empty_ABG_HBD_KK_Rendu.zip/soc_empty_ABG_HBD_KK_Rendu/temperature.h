// Fonction de lecture et de conversion de la temperature au format BLE
#define TEMPERATURE_TIMER_SIGNAL (1<<0)

struct my_context {
  uint8_t temp[2];
  uint8_t connection;
  uint16_t characteristic;
};
void conv_temp(uint8_t*);
void temp_callback(sl_sleeptimer_timer_handle_t*, void*);
struct my_context* get_context(void);
