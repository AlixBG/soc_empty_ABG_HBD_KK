/*
 * irradiance.h
 *
 *  Created on: 2 juin 2025
 *      Author: henry
 */

#ifndef IRRADIANCE_H_
#define IRRADIANCE_H_



#endif /* IRRADIANCE_H_ */
