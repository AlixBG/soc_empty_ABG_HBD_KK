/*
 * irradiance.c
 *
 *  Created on: 2 juin 2025
 *      Author: henry
 */


#include "sl_sensor_light.h"
#include "app_log.h"
#include "irradiance.h"
#include "sl_bt_api.h"

static uint8_t temp[2];
static struct my_context c;

void conv_irradiance(float* lux, float* uvi){

  app_log_info("%s: Reading irradiance\n",__FUNCTION__);
  sl_sensor_light_get(lux, uvi);

  //Conversion format BLE

}

void temp_callback(sl_sleeptimer_timer_handle_t *, void* data){
  //Read temperature
  sl_bt_evt_gatt_server_characteristic_status_t * toto = (sl_bt_evt_gatt_server_characteristic_status_t*) data;
  c.connection = toto->connection;
  c.characteristic = toto->characteristic;
  app_log_info("%s: %d, %d\n\n",__FUNCTION__, c.connection, c.characteristic);
  conv_temp(temp);
  c.temp[0] = temp[0];
  c.temp[1] = temp[1];
  sl_bt_external_signal(TEMPERATURE_TIMER_SIGNAL);
}
 struct my_context* get_context(){
   app_log_info("%s: %d, %d\n\n",__FUNCTION__, c.connection, c.characteristic);
   return &c;
 }
