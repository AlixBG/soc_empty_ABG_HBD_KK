#include "sl_sensor_rht.h"
#include "app_log.h"
#include "temperature.h"
#include "sl_bt_api.h"

static uint8_t temp[2];
static struct my_context c;

void conv_temp(uint8_t* Ttemp){

  //Declaration temp et humidity
  uint32_t rh;
  int32_t t;

  app_log_info("%s: Reading temp\n",__FUNCTION__);
  sl_sensor_rht_get(&rh, &t);

  //Conversion format BLE
  t=t/10; //Conversion format BLE
  int16_t tf = (int16_t)t;
  app_log_info("%s: temp converted\n",__FUNCTION__);

  //Affichage Temp sur Serial
  app_log_info("%s: temerature = %d !!\n",__FUNCTION__, tf);

  //Conversion de temp en un tableau de uint8_t
  Ttemp[0]= (uint8_t)(tf & 0xFF);
  Ttemp[1]= (uint8_t)((tf >> 8) & 0xFF);
}

void temp_callback(sl_sleeptimer_timer_handle_t *, void* data){
  //Read temperature
  sl_bt_evt_gatt_server_characteristic_status_t * toto = (sl_bt_evt_gatt_server_characteristic_status_t*) data;
  c.connection = toto->connection;
  c.characteristic = toto->characteristic;
  app_log_info("%s: %d, %d\n\n",__FUNCTION__, c.connection, c.characteristic);
  conv_temp(temp);
  c.temp[0] = temp[0];
  c.temp[1] = temp[1];
  sl_bt_external_signal(TEMPERATURE_TIMER_SIGNAL);
}
 struct my_context* get_context(){
   app_log_info("%s: %d, %d\n\n",__FUNCTION__, c.connection, c.characteristic);
   return &c;
 }
