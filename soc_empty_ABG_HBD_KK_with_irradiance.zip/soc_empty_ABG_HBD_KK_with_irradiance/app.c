/***************************************************************************//**
 * @file
 * @brief Core application logic.
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Zlib
 *
 * The licensor of this software is Silicon Laboratories Inc.
 *
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 *
 ******************************************************************************/
#include "em_common.h"
#include "app_assert.h"
#include "sl_bluetooth.h"
#include "app.h"
#include "app_log.h"
#include "sl_sensor_rht.h"
#include "temperature.h"
#include "gatt_db.h"
#include "sl_simple_led_instances.h"
// The advertising set handle allocated from Bluetooth stack.
static uint8_t advertising_set_handle = 0xff;
static sl_sleeptimer_timer_handle_t timer;
//static uint8_t notify_temp[2];



/**************************************************************************//**
 * Application Init.
 *****************************************************************************/
SL_WEAK void app_init(void)
{
  /////////////////////////////////////////////////////////////////////////////
  // Put your additional application init code here!                         //
  // This is called once during start-up.                                    //
  /////////////////////////////////////////////////////////////////////////////

  app_log_info("%s\n", __FUNCTION__);
}

/**************************************************************************//**
 * Application Process Action.
 *****************************************************************************/
SL_WEAK void app_process_action(void)
{
  /////////////////////////////////////////////////////////////////////////////
  // Put your additional application code here!                              //
  // This is called infinitely.                                              //
  // Do not call blocking functions from here!                               //
  /////////////////////////////////////////////////////////////////////////////
}

/**************************************************************************//**
 * Bluetooth stack event handler.
 * This overrides the dummy weak implementation.
 *
 * @param[in] evt Event coming from the Bluetooth stack.
 *****************************************************************************/
void sl_bt_on_event(sl_bt_msg_t *evt)
{
  sl_status_t sc;

  switch (SL_BT_MSG_ID(evt->header)) {
    // -------------------------------
    // This event indicates the device has started and the radio is ready.
    // Do not call any stack command before receiving this boot event!
    case sl_bt_evt_system_boot_id:
      // Create an advertising set.
      sc = sl_bt_advertiser_create_set(&advertising_set_handle);
      app_assert_status(sc);

      // Generate data for advertising
      sc = sl_bt_legacy_advertiser_generate_data(advertising_set_handle,
                                                 sl_bt_advertiser_general_discoverable);
      app_assert_status(sc);

      // Set advertising interval to 100ms.
      sc = sl_bt_advertiser_set_timing(
        advertising_set_handle,
        160, // min. adv. interval (milliseconds * 1.6)
        160, // max. adv. interval (milliseconds * 1.6)
        0,   // adv. duration
        0);  // max. num. adv. events
      app_assert_status(sc);
      // Start advertising and enable connections.
      sc = sl_bt_legacy_advertiser_start(advertising_set_handle,
                                         sl_bt_legacy_advertiser_connectable);
      app_assert_status(sc);
      break;

    // -------------------------------
    // This event indicates that a new connection was opened.
    case sl_bt_evt_connection_opened_id:
      sl_sensor_rht_init();
      sl_simple_led_init_instances();
      sl_sensor_light_init();
      app_log_info("%s: connection_opened !!\n",__FUNCTION__);
      break;

    // -------------------------------
    // This event indicates that a connection was closed.
    case sl_bt_evt_connection_closed_id:
      sl_sensor_rht_deinit();
      sl_sleeptimer_stop_timer(&timer);
      app_log_info("%s: connection_closed !!\n",__FUNCTION__);
      // Generate data for advertising
      sc = sl_bt_legacy_advertiser_generate_data(advertising_set_handle,
                                                 sl_bt_advertiser_general_discoverable);
      app_assert_status(sc);

      // Restart advertising after client has disconnected.
      sc = sl_bt_legacy_advertiser_start(advertising_set_handle,
                                         sl_bt_legacy_advertiser_connectable);
      app_assert_status(sc);
      break;

    ///////////////////////////////////////////////////////////////////////////
    // Add additional event handlers here as your application requires!      //
    ///////////////////////////////////////////////////////////////////////////
    case sl_bt_evt_gatt_server_user_read_request_id:

      if(evt->data.evt_gatt_server_user_read_request.characteristic==gattdb_temperature)
        {
          //Appel de la fonction de lecture et de conversion de la température
          uint8_t Ttemp[2];
          conv_temp(Ttemp);
          uint16_t len = 4; //longueur de la valeur
          app_log_info("%s: before send Ttemp[0]= %d  Ttemp[1]= %d \n",__FUNCTION__, Ttemp[0], Ttemp[1]);

          //Renvoye de la température
          sl_bt_gatt_server_send_user_read_response(evt->data.evt_gatt_server_user_read_request.connection,
                                                                evt->data.evt_gatt_server_user_read_request.characteristic,
                                                                0,
                                                                4,
                                                                Ttemp,
                                                                &len);
        }

      else app_log_info("%s: ID KO = %d \n",__FUNCTION__,evt->data.evt_gatt_server_user_read_request.characteristic);
      break;

    case sl_bt_evt_gatt_server_characteristic_status_id:
      switch(evt->data.evt_gatt_server_characteristic_status.characteristic){
        case gattdb_temperature:
                app_log_info("%s: User modify Notify function for temperature \n",__FUNCTION__);
                //app_log_info("%s: status_flags : %d \n",__FUNCTION__,evt->data.evt_gatt_server_characteristic_status.status_flags);
                if(evt->data.evt_gatt_server_characteristic_status.status_flags==1)
                  {
                    app_log_info("%s: Clique sur notify\n",__FUNCTION__);
                  if(evt->data.evt_gatt_server_characteristic_status.client_config_flags==1)
                    {
                      app_log_info("%s: client_Subscribed to temp\n",__FUNCTION__);
                      app_log_info("%s: client_config flags : %d \n",__FUNCTION__,evt->data.evt_gatt_server_characteristic_status.client_config_flags);
                      static sl_bt_evt_gatt_server_characteristic_status_t my_status;
                      my_status.characteristic = evt->data.evt_gatt_server_characteristic_status.characteristic;
                      my_status.connection = evt->data.evt_gatt_server_characteristic_status.connection;
                      app_log_info("%s: %d, %d\n\n",__FUNCTION__, my_status.connection, my_status.characteristic);

                      void *data = (void*) &my_status;
                      sl_sleeptimer_start_periodic_timer_ms(&timer, 1000, temp_callback, data, 0, 0);
                      app_log_info("%s: START Timer \n\n",__FUNCTION__);
                    }
                  else
                    {
                      app_log_info("%s: client_Unbscribed to temp\n",__FUNCTION__);
                      app_log_info("%s: client_config flags : %d \n",__FUNCTION__,evt->data.evt_gatt_server_characteristic_status.client_config_flags);
                      sl_sleeptimer_stop_timer(&timer);
                      app_log_info("%s: STOP Timer \n\n",__FUNCTION__);
                    }
                  }
        break;
        case gattdb_irradiance_0:
          app_log_info("%s: User irradiance read \n",__FUNCTION__);


        break;
      }
      break;

    case sl_bt_evt_system_external_signal_id:
      app_log_info("%s: ext signal: %ld\n",__FUNCTION__, evt->data.evt_system_external_signal.extsignals);
      if (evt->data.evt_system_external_signal.extsignals == TEMPERATURE_TIMER_SIGNAL){
          struct my_context * val =  get_context();
          app_log_info("%s: %d, %d, %d, %d\n\n",__FUNCTION__, val->connection, val->characteristic, val->temp[0], val->temp[1]);
          sl_bt_gatt_server_send_notification(val->connection,
                                              val->characteristic,
                                              2,
                                              val->temp);
      }
    break;

    case sl_bt_evt_gatt_server_user_write_request_id:
        if (evt->data.evt_gatt_server_user_write_request.characteristic==31){
            app_log_info("%s: User Write Request on Automation IO\n",__FUNCTION__);
          if (evt->data.evt_gatt_server_user_write_request.characteristic==18){
              sl_bt_gatt_server_send_user_write_response(evt->data.evt_gatt_server_user_write_request.connection,
                                                         evt->data.evt_gatt_server_user_write_request.characteristic,
                                                         0);
              app_log_info("%s: Sent server response\n",__FUNCTION__);
          }
          // handle LED
          uint8_t len = evt->data.evt_gatt_server_user_write_request.value.len;
          uint8_t data[len];
          memcpy(data, evt->data.evt_gatt_server_user_write_request.value.data, len);

          for (int i=0; i<len;i++) app_log_info("%s: write %d\n",__FUNCTION__, data[i]);
          if (data[0]==1){
              sl_simple_led_turn_on((void*)sl_led_led0.context);
              app_log_info("%s: led on\n",__FUNCTION__);
          }
          else if (data[0]==0){
              sl_simple_led_turn_off((void*)sl_led_led0.context);
              app_log_info("%s: led off\n",__FUNCTION__);
          }

      }
    break;

    // -------------------------------
    // Default event handler.
    default:
      break;
  }
}
